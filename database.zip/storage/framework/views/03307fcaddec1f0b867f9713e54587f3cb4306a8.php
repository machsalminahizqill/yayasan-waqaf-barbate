<div>
    <!-- Order your soul. Reduce your wants. - Augustine -->
</div>

<form method="post">
    <textarea id="myeditorinstance">Hello, World!</textarea>
</form>
<?php /**PATH D:\12. Barbate\web\Barbate\resources\views/components/forms/tinymce-editor.blade.php ENDPATH**/ ?>