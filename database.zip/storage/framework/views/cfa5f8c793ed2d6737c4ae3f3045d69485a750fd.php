<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tw-elements/dist/css/index.min.css" />
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/tw-elements/dist/js/index.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main class="">
        <div
            id="carouselExampleCrossfade"
            class="carousel slide carousel-fade relative"
            data-bs-ride="carousel">
            <div class="carousel-indicators absolute right-0 bottom-0 left-0 flex justify-center p-0 mb-4">
                <button
                type="button"
                data-bs-target="#carouselExampleCrossfade"
                data-bs-slide-to="0"
                class="active"
                aria-current="true"
                aria-label="Slide 1"
                ></button>
                <button
                type="button"
                data-bs-target="#carouselExampleCrossfade"
                data-bs-slide-to="1"
                aria-label="Slide 2"
                ></button>
                <button
                type="button"
                data-bs-target="#carouselExampleCrossfade"
                data-bs-slide-to="2"
                aria-label="Slide 3"
                ></button>
            </div>
            <div class="carousel-inner relative w-full overflow-hidden">
                <div class="carousel-item active float-left w-full">
                    <img
                        src="https://mdbcdn.b-cdn.net/img/new/slides/041.webp"
                        class="block w-full"
                        alt="Wild Landscape"
                    />
                </div>
                <div class="carousel-item float-left w-full">
                    <img
                        src="https://mdbcdn.b-cdn.net/img/new/slides/042.webp"
                        class="block w-full"
                        alt="Camera"
                    />
                </div>
                <div class="carousel-item float-left w-full">
                    <img
                        src="https://mdbcdn.b-cdn.net/img/new/slides/043.webp"
                        class="block w-full"
                        alt="Exotic Fruits"
                    />
                </div>
            </div>
            <button
                class="carousel-control-prev absolute top-0 bottom-0 flex items-center justify-center p-0 text-center border-0 hover:outline-none hover:no-underline focus:outline-none focus:no-underline left-0"
                type="button"
                data-bs-target="#carouselExampleCrossfade"
                data-bs-slide="prev"
            >
                <span class="carousel-control-prev-icon inline-block bg-no-repeat" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button
                class="carousel-control-next absolute top-0 bottom-0 flex items-center justify-center p-0 text-center border-0 hover:outline-none hover:no-underline focus:outline-none focus:no-underline right-0"
                type="button"
                data-bs-target="#carouselExampleCrossfade"
                data-bs-slide="next"
            >
                <span class="carousel-control-next-icon inline-block bg-no-repeat" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>

        <div id="nama-yayasan" class="w-3/4 mx-auto my-6">
            <h1 class="text-xl md:text-3xl text-center my-8 font-bold border-y-2 border-y-emerald-400  py-2">
                YAYASAN WAQAF BARBATE ISLAMIC CITY
            </h1>
        </div>

        <div id="news" class="leftright">
            <div id="header-news" class="mb-4">
                <p class="border-l-4 pl-2 font-semibold uppercase border-emerald-500 text-lg md:text-2xl text-emerald-500">
                    Berita Terbaru
                </p>
            </div>
            <div id="body-news">
                <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="lg:flex lg:justify-start lg:gap-4 mb-6 p-4 lg:p-6 bg-slate-50">
                        <div class="lg:w-1/3 select-none">
                            <img src="<?php echo e($berita->gambar); ?>" alt="">
                        </div>
                        <div class="lg:w-2/3 mt-3 lg:mt-0">
                            <a href="<?php echo e('/berita/' . $berita->slug . '.' . $berita->id); ?>"
                                class="text-lg  font-bold leading-tight uppercase transition-all duration-500 ease-in-out hover:text-[#1abc9c]">
                                <h3><?php echo e($berita->judul); ?></h3>
                            </a>
                            <div class="flex mt-2">
                                <p class="text-gray-600 text-xs md:text-sm cursor-default hover:text-black">
                                    <?php echo e($berita->created_at->format('d M Y H:i')); ?>

                                </p>
                            </div>
                            <p class="mt-2 cursor-default text-gray-800 text-base text-justify line-clamp-4">Lorem, ipsum dolor
                                <?php echo e($berita->konten); ?>

                            </p>
                            <div class="mt-2 md:mt-8">
                                <a href="<?php echo e('/berita/' . $berita->slug . '.' . $berita->id); ?>" class="px-6 py-1 md:py-1.5 bg-emerald-600 hover:bg-emerald-700 rounded-md text-white">Lihat Selengkapnya</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\12. Barbate\web\Barbate\resources\views/guest/pages/beranda.blade.php ENDPATH**/ ?>