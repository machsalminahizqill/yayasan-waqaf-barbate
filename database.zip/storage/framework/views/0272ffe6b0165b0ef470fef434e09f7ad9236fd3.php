<?php $__env->startSection('content'); ?>
    <main class="leftright my-8 min-h-[80vh]">
        <div class="lg:flex gap-4">
            <div class="w-full lg:w-3/4 ">
                <h1 class="text-lg md:text-2xl lg:text-2xl font-semibold leading-5">
                    <?php echo e($berita->judul); ?>

                </h1>
                <div class="mt-2">
                    <p class="text-gray-600 text-sm md:text-base  cursor-default hover:text-black">
                        <?php echo e($berita->created_at->format('d M Y H:i')); ?>

                    </p>
                </div>
                <div class="mt-4 md:mt-6">
                    <img src="<?php echo e($berita->gambar); ?>" alt="">
                </div>
                <div class="mt-4 md:mt-6">
                    <div class="text-justify leading-6 text-[#3b3b3b] mt-1">
                        <?php echo $berita->konten; ?>

                    </div>
                </div>
            </div>
            <div class="w-full md:w-1/4 mt-4 md:mt-0 relative">
                <div class="md:sticky md:top-24 md:left-0">
                    <h3 class="text-lg lg:text-xl font-semibold"> Berita Lainnya</h3>
                    <div class="line line-xs line-market"></div>
                    <div class="flex-row gap-4 pt-2">
                        <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="flex gap-2 mb-4 w-full">
                                <div class="w-2/6">
                                    <img class="rounded mt-1" src="<?php echo e($item->gambar); ?>" alt="">
                                </div>
                                <div class="w-5/6">
                                    <a href="<?php echo e('/berita/' . $item->slug . '.' . $item->id); ?>" class="text-sm  line-clamp-2 leading-4  transition-all duration-300 ease-in-out hover:text-[#1abc9c]">
                                        <?php echo e($item->judul); ?>

                                    </a>
                                    <div class="mt-1">
                                        <p class="text-gray-600 text-xs  cursor-default hover:text-black"> <?php echo e($item->created_at->format('d M Y H:i')); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\12. Barbate\Barbate\resources\views/guest/pages/berita/detail.blade.php ENDPATH**/ ?>