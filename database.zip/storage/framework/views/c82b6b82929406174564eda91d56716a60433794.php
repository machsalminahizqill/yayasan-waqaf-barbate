<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tw-elements/dist/css/index.min.css" />

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="min-h-[80vh] flex justify-center items-center">
    <section class="-mt-14 text-center">
        <p class="text-xl">Donasi Sedang Maintenance</p>
        <div class="mt-4">
            <a class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 rounded text-white" href="/">Kembali Ke beranda</a>
        </div>
    </section>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\12. Barbate\Barbate\resources\views/guest/pages/donasi/maintenance.blade.php ENDPATH**/ ?>