<?php $__env->startSection('content'); ?>
<div class="min-h-screen"> </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\12. Barbate\web\Barbate\resources\views/guest/pages/profil/misi.blade.php ENDPATH**/ ?>