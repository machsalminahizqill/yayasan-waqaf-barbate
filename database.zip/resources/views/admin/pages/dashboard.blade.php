@extends('admin.layout.master')

@section('content')

@endsection
