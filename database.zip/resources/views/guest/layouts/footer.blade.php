<footer class="w-auto bg-gray-800 p-6 flex flex-col justify-center items-center">
    <div id="social-media" class="my-2">
        <a href=""><i
                class="fa-brands fa-facebook mx-2 text-lg lg:text-2xl text-white hover:text-emerald-200 transition-all duration-500 ease-in-out"></i></a>
        <a href=""><i
                class="fa-brands fa-whatsapp mx-2 text-lg lg:text-2xl text-white hover:text-emerald-200 transition-all duration-500 ease-in-out"></i></a>
    </div>
    <div id="copyright">
        <p class="text-white text-xs md:text-base">Copyright &copy; 2022 - Yayasan Waqaf Barbate Islamic City All Rights
            Reserved</p>
    </div>
</footer>
