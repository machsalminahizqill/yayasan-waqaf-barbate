<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/tinymce/tinymce.min.js')); ?>" referrerpolicy="origin"></script>
<script>
  tinymce.init({
    selector: 'textarea#myeditorinstance', // Replace this CSS selector to match the placeholder element for TinyMCE
    plugins: 'code table lists',
    toolbar: 'undo redo | formatselect| bold italic | alignleft aligncenter alignright | indent outdent | bullist numlist | code | table'
  });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main class="leftright">
        <div id="form" class="mt-8">
            <form action="<?php echo e(route('editBeritaAdmin')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($berita->id); ?>">
                <div class="mb-6">
                    <label for="judul" class="block mb-1 text-sm  font-medium">Judul
                        <span class="text-emerald-400 ">
                            <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                | <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </label>
                    <input type="judul" id="judul" name="judul" value="<?php echo e($berita->judul); ?>"
                        class="border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                </div>
                <div class="mb-6">
                    <label for="email" class="block mb-1 text-sm font-medium text-gray-900">Konten
                        <span class="text-emerald-400 ">
                            <?php $__errorArgs = ['konten'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                | <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </label>
                    <textarea id="myeditorinstance" name="konten"><?php echo e($berita->konten); ?></textarea>
                </div>
                <div class="mb-6">
                    <label for="gambar" class="block mb-1 text-sm  font-medium">gambar
                        <span class="text-emerald-400 ">
                            <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                | <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </label>
                    <input type="file" id="gambar" name="gambar" value="<?php echo e(old('gambar')); ?>"
                        class="border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                        >
                </div>

                <div class="flex gap-2">
                    <a href="/admin/berita/<?php echo e($berita->slug); ?>/<?php echo e($berita->id); ?>" class="px-6 py-1 bg-slate-600 hover:bg-slate-700 rounded-md text-white">Kembali</a>
                    <button type="submit"
                    class="px-6 py-1 bg-sky-600 hover:bg-cyan-700 rounded-md text-white">Simpan</button>
                </div>

            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\04. Aplikasi\00. Valet\Barbate\resources\views/admin/pages/berita/edit.blade.php ENDPATH**/ ?>