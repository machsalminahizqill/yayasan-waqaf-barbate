<?php $__env->startSection('css'); ?>
    <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <link rel="preload" as="image" href="<?php echo e($item->gambar); ?>" >
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main id="news" class="leftright py-4 lg:py-8 min-h-[80vh]">
        <div id="header-news" class="mb-4">
            <p class="border-l-4 pl-2 font-semibold border-emerald-500 text-lg lg:text-2xl text-emerald-500">
                Semua Berita
            </p>
        </div>
        <div id="body-news">
            <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="lg:flex lg:justify-start lg:gap-4 mb-6 p-4 lg:p-6 bg-slate-50">
                    <div class="lg:w-1/3 select-none">
                        <img src="<?php echo e($berita->gambar); ?>" alt="">
                    </div>
                    <div class="lg:w-2/3 mt-3 lg:mt-0">
                        <a href="<?php echo e('/berita/' . $berita->slug . '.' . $berita->id); ?>"
                            class="text-lg  font-bold leading-tight uppercase transition-all duration-500 ease-in-out hover:text-[#1abc9c]">
                            <h3><?php echo e($berita->judul); ?></h3>
                        </a>
                        <div class="flex mt-2">
                            <p class="text-gray-600 text-xs md:text-sm cursor-default hover:text-black">
                                <?php echo e($berita->created_at->format('d M Y H:i')); ?>

                            </p>
                        </div>
                        <div class="mt-2 cursor-default text-gray-800 text-base text-justify line-clamp-4">
                            <?php echo $berita->konten; ?>

                        </div>
                        <div class="mt-4 md:mt-8">
                            <a href="<?php echo e('/berita/' . $berita->slug . '.' . $berita->id); ?>"
                                class="px-6 py-1.5 md:py-1.5 bg-emerald-600 hover:bg-emerald-700 rounded-md text-white">Lihat
                                Selengkapnya</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo e($beritas->links('pagination::tailwind')); ?>

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\04. Aplikasi\00. Valet\Barbate\resources\views/guest/pages/berita/main.blade.php ENDPATH**/ ?>