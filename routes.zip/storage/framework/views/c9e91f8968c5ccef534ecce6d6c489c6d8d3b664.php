<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/tinymce/tinymce.min.js')); ?>" referrerpolicy="origin"></script>
<script>
  tinymce.init({
    selector: 'textarea#myeditorinstance', // Replace this CSS selector to match the placeholder element for TinyMCE
    plugins: 'code table lists',
    toolbar: 'undo redo | formatselect| bold italic | alignleft aligncenter alignright | indent outdent | bullist numlist | code | table'
  });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main class="leftright">
        <div id="form" class="mt-8">
            <form action="" method="post">
                <div class="mb-6">
                    <label for="judul" class="block mb-1 text-sm font-medium text-gray-900">Judul</label>
                    <input type="judul" id="judul"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                        required>
                </div>
                <div class="mb-6">
                    
                    <textarea id="myeditorinstance"></textarea>
                </div>

                <div class="flex gap-2">
                    <a href="/admin/berita/detail" class="px-6 py-1 bg-slate-600 hover:bg-slate-700 rounded-md text-white">Kembali</a>
                    <button type="submit"
                    class="px-6 py-1 bg-sky-600 hover:bg-cyan-700 rounded-md text-white">Simpan</button>
                </div>

            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\12. Barbate\web\Barbate\resources\views/admin/pages/berita/edit.blade.php ENDPATH**/ ?>