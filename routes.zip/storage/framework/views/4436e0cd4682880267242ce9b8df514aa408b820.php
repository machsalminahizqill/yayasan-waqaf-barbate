<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tw-elements/dist/css/index.min.css" />

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/tw-elements/dist/js/index.min.js"></script>

<script>
    function toggleForm() {
        const tombolDonasi = document.getElementById('tombol-donasi');
        const formulir = document.querySelector('form');
        formulir.classList.toggle("hidden");
    }

    function togglePembayaran() {
        const buttonGantiPembayaran = document.querySelector('button');
        const metodePembayaran = document.getElementById('nama-bank');

        metodePembayaran.classList.toggle('hidden');
    }
</script>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="">


    <section class=" mx-auto w-full   pt-1 lg:w-6/12">

        <!-- carousel -->
        <div id="carouselExampleControls" class="carousel slide relative mt-6" data-bs-ride="carousel">
            <div class="carousel-inner relative w-full overflow-hidden">
                <div class="carousel-item active relative float-left w-full">
                    <img src="https://mdbcdn.b-cdn.net/img/new/slides/041.webp" class="block w-full" alt="Wild Landscape" />
                </div>
                <div class="carousel-item relative float-left w-full">
                    <img src="https://mdbcdn.b-cdn.net/img/new/slides/042.webp" class="block w-full" alt="Camera" />
                </div>
                <div class="carousel-item relative float-left w-full">
                    <img src="https://mdbcdn.b-cdn.net/img/new/slides/043.webp" class="block w-full" alt="Exotic Fruits" />
                </div>
            </div>
            <button class="carousel-control-prev absolute top-0 bottom-0 flex items-center justify-center p-0 text-center border-0 hover:outline-none hover:no-underline focus:outline-none focus:no-underline left-0" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                <span class="carousel-control-prev-icon inline-block bg-no-repeat" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next absolute top-0 bottom-0 flex items-center justify-center p-0 text-center border-0 hover:outline-none hover:no-underline focus:outline-none focus:no-underline right-0" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                <span class="carousel-control-next-icon inline-block bg-no-repeat" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>

        <div class="pb-24">
            <div class="flex justify-center">
                <button id="tombol-donasi" onclick="toggleForm()" class="block px-16 py-1.5 mb-4 mt-8 text-center text-md bg-emerald-500 rounded-lg text-gray-100 hover:bg-emerald-600 hover:font-semibold md:text-base">
                    Donasi Sekarang
                </button>
            </div>
            <form class="hidden">
                <ul>
                    <li class="border border-gray-300 w-11/12 p-3 mb-8">
                        <label for="donasi" class="block mb-4 text-sm font-semibold">Nominal Donasi <span class="text-red-500">*</span></label>
                        <input type="text" placeholder="0" id="donasi" name="donasi" value="0"
                            class="border bg-gray-200 border-gray-300  placeholder:text-gray-900 text-gray-900 text-sm rounded-sm focus:ring-emerald-500 focus:border-emerald-500 block w-full px-2.5 py-1 pt-2">
                        <p class="text-xs text-gray-700 mt-1">miminal donasi Rp. 10.000</p>
                    </li>
                    <li class="border border-gray-300 w-11/12 p-3 mb-8">
                        <p class="mb-4 text-sm font-semibold">Lengkapi Data Donatur</p>
                        <label for="nama" class="block text-sm mb-2">Nama Lengkap</label>
                        <input type="text" id="nama" name="nama" value="<?php echo e(old('nama')); ?>"
                            class="mb-4 border bg-gray-200 border-gray-300  placeholder:text-gray-900 text-gray-900 text-sm rounded-sm focus:ring-emerald-500 focus:border-emerald-500 block w-full px-2.5 py-1 pt-1.5">

                        <label for="hp" class="block text-sm mb-2">Hp</label>
                        <input type="number" id="hp" name="hp" value="<?php echo e(old('hp')); ?>"
                        class="mb-4 border bg-gray-200 border-gray-300  placeholder:text-gray-900 text-gray-900 text-sm rounded-sm focus:ring-emerald-500 focus:border-emerald-500 block w-full px-2.5 py-1 pt-1.5">

                    </li>
                    <li class="border border-gray-300 w-11/12 p-3 mb-8">
                        <p class="mb-4 text-sm font-semibold">Pilih Metode Pembayaran</p>
                        <div class="mb-3 p-2 flex justify-between items-center bg-gray-100">
                            <span class="text-sm">nama bank</span>
                            <span class="text-sm mr-44">Mandiri</span>
                            <button type="button" onclick="togglePembayaran()" class="py-1 px-3 bg-emerald-400 rounded-2xl text-sm hover:bg-emerald-500">Ganti
                                Pembayaran
                                <svg xmlns="http://www.w3.org/2000/svg" class="inline" width="16" height="16" fill="currentColor" class="bi bi-caret-down-fill" viewBox="0 0 16 16">
                                    <path d="M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z" />
                                </svg>
                            </button>
                        </div>
                        <div id="nama-bank" class="hidden">
                            <div class="mb-2">
                                <input type="radio" name="nama-bank" id="mandiri">
                                <label for="mandiri">Mandiri</label>
                            </div>
                            <div class="mb-2">
                                <input type="radio" name="nama-bank" id="bsi">
                                <label for="bsi">BSI</label>
                            </div>
                            <div class="mb-2">
                                <input type="radio" name="nama-bank" id="cimb-niaga">
                                <label for="cimb-niaga">Cimb Niaga</label>
                            </div>
                        </div>
                    </li>
                </ul>
            </form>
            <p class="mt-2 mb-5 text-center text-sm md:text-lg">atau donasi melalui</p>
            <div class="flex gap-4 p-4 border border-slate-200">
                <a href="" class=" w-10/12 border border-slate-200 bg-slate-100 hover:bg-slate-200 rounded-md py-2 md:w-11/12">
                    <img src="<?php echo e(asset('assets/donasi/image/logo-kitabisa.jpg')); ?>" alt="" class="w-10 rounded-full mb-3 inline-block ml-2">
                    <span class="items-center ml-1 text-sm">Kitabisa.com</span>
                    <img src="<?php echo e(asset('assets/donasi/image/ilustrasi donasi.jpg')); ?>" alt="">
                    <p class="text-xs py-4 px-6 text-center md:text-base md:px-2">Ayo bantu saudara kita yang sedang
                        menempuh pendidikan dengan
                        membangun
                        gedung
                        sekolah</p>
                </a>
                <a href="" class=" w-10/12 border border-slate-200 bg-slate-100 hover:bg-slate-200 rounded-md py-2 md:w-11/12">
                    <img src="<?php echo e(asset('assets/donasi/image/logo-kitabisa.jpg')); ?>" alt="" class="w-10 rounded-full mb-3 inline-block ml-2">
                    <span class="items-center ml-1 text-sm">Kitabisa.com</span>
                    <img src="<?php echo e(asset('assets/donasi/image/ilustrasi donasi.jpg')); ?>" alt="">
                    <p class="text-xs py-4 px-6 text-center md:text-base md:px-2">Ayo bantu saudara kita yang sedang
                        menempuh pendidikan dengan
                        membangun
                        gedung
                        sekolah</p>
                </a>
                <!-- <a href="" class="mb-4 inline-block w-3/4">
                        <img src="../images/logo-kitabisa.jpg" alt="" class="w-10 rounded-full mb-3 inline-block">
                        <span class="items-center ml-1"></span>Kitabisa.com</span>
                        <img src="../images/ilustrasi donasi.jpg" alt="">
                        <p>Ayo bantu saudara kita yang sedang menempuh pendidikan dengan membangun gedung sekolah</p>
                    </a> -->
            </div>
        </div>

        <!-- <div>
                <form action="">
                    <ul>
                        <li>
                            <label for="nama">Nama</label>
                            <input type="text" name="nama" id="nama" class="bg-blue-300">
                        </li>
                        <li>
                            <label for=""></label>
                        </li>
                    </ul>
                </form>
            </div> -->
        <!-- <img src="../images/percobaan.jpg" alt=""> -->
    </main>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\04. Aplikasi\00. Valet\Barbate\resources\views/guest/pages/donasi/main.blade.php ENDPATH**/ ?>