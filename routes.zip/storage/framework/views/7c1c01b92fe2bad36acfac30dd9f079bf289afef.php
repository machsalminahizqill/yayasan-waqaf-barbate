<?php $__env->startSection('content'); ?>
<main class="pb-24">
    <div class="leftright mt-8">
        <div class="flex">
            <a href="<?php echo e(route('tambahBeritaAdmin')); ?>" class="px-6 py-1 bg-sky-600 hover:bg-cyan-700 rounded-md text-white">Tambah Berita</a>
        </div>
    </div>
    <div id="news" class="leftright mt-8 ">
        <div id="body-news">
            <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="md:flex md:justify-start md:gap-4 mb-6">
                    <div class="md:w-1/3 select-none">
                        <img src="<?php echo e($berita->gambar); ?>" alt="">
                    </div>
                    <div class="md:w-2/3 mt-3 md:mt-0">
                        <a href="#"
                            class="text-lg  font-bold leading-tight uppercase transition-all duration-500 ease-in-out hover:text-[#1abc9c]">
                            <h3><?php echo e($berita->judul); ?></h3>
                        </a>
                        <div class="flex mt-2">
                            <p class="text-gray-600 text-xs md:text-sm cursor-default hover:text-black">
                                <?php echo e($berita->created_at->format('d M Y H:i')); ?>

                            </p>
                        </div>
                        <div class="mt-2 cursor-default text-gray-800 text-base text-justify line-clamp-4">
                            <?php echo $berita->konten; ?>

                        </div>
                        <div class="flex gap-2 mt-2">
                            <a href="/admin/berita/<?php echo e($berita->slug); ?>/<?php echo e($berita->id); ?>" class="px-6 py-1 bg-cyan-600 hover:bg-cyan-700 rounded-md text-white">Detail</a>
                            <a href="/admin/berita/edit/<?php echo e($berita->slug); ?>/<?php echo e($berita->id); ?>" class="px-6 py-1 bg-amber-600 hover:bg-amber-700 rounded-md text-white">Edit</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\04. Aplikasi\00. Valet\Barbate\resources\views/admin/pages/berita/main.blade.php ENDPATH**/ ?>