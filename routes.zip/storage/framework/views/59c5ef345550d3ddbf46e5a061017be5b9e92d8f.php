<?php $__env->startSection('content'); ?>
<main>
    <div class="leftright mt-8">
        <div class="flex">
            <a href="<?php echo e(route('tambahBeritaAdmin')); ?>" class="px-6 py-1 bg-sky-600 hover:bg-cyan-700 rounded-md text-white">Tambah Berita</a>
        </div>
    </div>
    <div id="news" class="leftright mt-8">
        <div id="body-news">
            <div class="md:flex md:justify-start md:gap-4 mb-6">
                <div class="md:w-1/3 select-none">
                    <img src="/assets/12.jpg" alt="">
                </div>
                <div class="md:w-2/3 mt-3 md:mt-0">
                    <a href="#"
                        class="text-lg  font-bold leading-tight uppercase transition-all duration-500 ease-in-out hover:text-[#1abc9c]">
                        <h3>PELATIHAN SEBAGAI PENDAMPING PPH MASJID RAYA BAITURRAHMAN HALAL CENTER</h3>
                    </a>
                    <div class="flex mt-2">
                        <p class="text-gray-600 text-xs md:text-sm cursor-default hover:text-black">25 Aug 2022 09:00
                            WIB</p>
                    </div>
                    <p class="mt-2 cursor-default text-gray-800 text-base text-justify line-clamp-4">Lorem, ipsum dolor
                        sit amet consectetur adipisicing elit. Corporis sed libero pariatur nihil tempora dicta numquam
                        nulla? Aut delectus soluta, sapiente molestias modi suscipit pariatur sequi. Libero accusantium
                        ab iure. Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus necessitatibus
                        reprehenderit rem debitis omnis sequi. Error iusto sint voluptates blanditiis iste quam odit
                        aspernatur esse. Quaerat commodi iusto nisi ipsa!
                    </p>
                    <div class="flex gap-2 mt-2">
                        <a href="/admin/berita/detail" class="px-6 py-1 bg-cyan-600 hover:bg-cyan-700 rounded-md text-white">Detail</a>
                        <a href="/admin/berita/edit" class="px-6 py-1 bg-amber-600 hover:bg-amber-700 rounded-md text-white">Edit</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\12. Barbate\web\Barbate\resources\views/admin/pages/berita/main.blade.php ENDPATH**/ ?>